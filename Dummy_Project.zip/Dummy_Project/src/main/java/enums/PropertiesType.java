package enums;

public enum PropertiesType 
{
	sport,
	music,
	reading,
	gender,
	chromeops

}
