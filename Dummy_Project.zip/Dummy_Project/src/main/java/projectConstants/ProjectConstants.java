package projectConstants;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import lombok.Getter;
import utility.Print_Utility;
import utility.Properties_utility;



public class ProjectConstants 
{
	
	
	private static final Logger logger= LogManager.getLogger(Properties_utility.class);
	private ProjectConstants() {	}
	private static ProjectConstants INSATANCE=null;
	public static ProjectConstants getINSTANCE()
	{
		if (INSATANCE==null)
		{
			INSATANCE= new ProjectConstants();
		}
		
		return INSATANCE;
	}
	
	private final String Config_file_path=System.getProperty("user.dir")+"\\src\\resource\\java\\Config.properties";
	private final String input_image_folder_path=System.getProperty("user.dir")+"\\Input_Files\\Images\\";
	private final String input_setup_folder_path=System.getProperty("user.dir")+"\\Input_Files\\setUpExes\\";
	private final String output_extent_repo_path=System.getProperty("user.dir")+"\\ExtentReport_logs\\";
	private final String output_Screenshot_path=System.getProperty("user.dir")+"\\Screenshots\\";
	public String getConfig_file_path() 
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);
		return Config_file_path;
	}
	public String get_input_image_folder_path(String image_file_name)
	{
		return (input_image_folder_path+image_file_name).toString();
	}
	public String get_input_setup_folder_path(String image_file_name)
	{
		return (input_setup_folder_path+image_file_name).toString();
	}
	public String get_output_extent_repo_path(String reportName)
	{
		return (output_extent_repo_path+reportName).toString();
	}
	public String get_output_Screenshot_path(String Screenshotname)
	{
		return (output_Screenshot_path+Screenshotname).toString();
	}
	
	public static void main(String[] args) {
		Print_Utility.get_print(ProjectConstants.getINSTANCE().get_input_image_folder_path("images (8).jpg"));
	}

}
