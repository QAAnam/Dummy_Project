package practice;

import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import enums.PropertiesType;
import projectConstants.ProjectConstants;
import utility.Print_Utility;
import utility.Properties_utility;
import utility.Robo_utility;
import utility.SeleniumUtil;
import utility.WaitUtility;

public class P1 {
	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get("https://demoqa.com/automation-practice-form");
		driver.navigate().refresh();
		SeleniumUtil.sendKey_to_element(driver.findElement(By.xpath("//input[@id='uploadPicture']")),ProjectConstants.getINSTANCE().get_input_image_folder_path("images (8).jpg"), driver);
		
		
	}

}
