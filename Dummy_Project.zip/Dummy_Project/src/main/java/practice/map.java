package practice;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class map 
{
	public static void main(String[] args) {
		Map<String, List<Object>> a = new HashMap<String, List<Object>>();
		for(int i=0;i<10;i++)
		{
			List<Object> li = new ArrayList<Object>();
			li.add(i);
			li.add(i*i);
			a.put("anam"+i, li);
		}
		System.out.println(a);
		Set<String> a_key = a.keySet();
		List<String> a_key_list= new ArrayList<String>(a_key);
		Collections.sort(a_key_list);
		int i=0;
		for(i=0;i<10;i++)
		{
			System.out.println(a_key_list.get(i)+ " ,"+ a.get(a_key_list.get(i)));
			
		}
		for(String s:a_key_list)
		{
			System.out.println(s +" ,"+a.get(s));
			List<Object> z = a.get(s);
			//cell0 = s, cell1 = z.get 0, cell2 z.get1;
		}
	}
	

}
