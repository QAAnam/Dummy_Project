package practice;

import utility.Print_Utility;

public class calling 
{
	public static void A()
	{
		Print_Utility.get_print(new Object() {}.getClass().getName()+">>>"+new Object() {}.getClass().getEnclosingMethod().getName());
	}
	public  static void B(String s)
	{
		Print_Utility.get_print(s.getClass().getName());
		Print_Utility.get_print(s.getClass().getEnclosingMethod().getName());
		Print_Utility.get_print(new Object() {}.getClass().getName()+">>>"+new Object() {}.getClass().getEnclosingMethod().getName());
	}
	public static void main(String[] args) {
		A();
		B("x");
	}

}
