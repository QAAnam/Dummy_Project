package practice;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ById;
import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.Options;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import utility.Print_Utility;
import utility.SeleniumUtil;
import utility.WaitUtility;

public class Practice {
	public static void main() {
		ChromeOptions ops = new ChromeOptions();
		ops.addExtensions(new File("C:\\Users\\anam.kumar\\Downloads\\adblock.crx"));
		ops.setPageLoadStrategy(PageLoadStrategy.NORMAL);
		ops.addArguments("start-maximized");
		ops.addArguments("disable-infobars");
		ops.setExperimentalOption("excludeSwitches", Collections.singletonList("enable-automation"));
		ops.setExperimentalOption("useAutomationExtension", false);
		//ops.addArguments("headless");
		WebDriver driver=new ChromeDriver(ops);
		driver.get("https://demoqa.com/automation-practice-form");
		System.out.println("done");
		Set<String> win = driver.getWindowHandles();
		List<String> li = new ArrayList<String>(win);
		driver.switchTo().window(li.get(1));
		Print_Utility.get_print(driver.getTitle());
		driver.close();
		driver.switchTo().window(li.get(0));
		Print_Utility.get_print(driver.getTitle());
		WebElement gender1=driver.findElement(By.xpath("//label[@for='gender-radio-1']"));
		boolean s = gender1.isSelected();
		Print_Utility.get_print(s);
		SeleniumUtil.click_on_element(gender1, driver);
		s = gender1.isSelected();
		Print_Utility.get_print(s);
		driver.navigate().refresh();
		WaitUtility.waitforsec(3);
		WebElement gendermale = driver.findElement(By.id("gender-radio-1"));
		boolean s1 = gendermale .isSelected();
		Print_Utility.get_print(s1);
		
		SeleniumUtil.click_on_element(gendermale, driver);
		
		s1 = gendermale .isSelected();
		
		Print_Utility.get_print(s1);
		WaitUtility.waitforsec(6);
		driver.quit();
		
	}
	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.get("https://demoqa.com/automation-practice-form");
		driver.findElement(By.id("firstName")).sendKeys("Anam");
		Print_Utility.get_print(driver.findElement(By.id("firstName")).getText());
		SeleniumUtil.click_on_element(driver.findElement(By.id("dateOfBirthInput")), driver);
	}

}
