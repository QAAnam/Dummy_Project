package practice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class P2 
{
	
	public static void main(String[] args) {
		String [] a=new String[5];
		a[1]="123";
		System.out.println(Arrays.toString(a));
		
		List<String> li = new ArrayList<String>();
		
		List<String> li1 = new LinkedList<String>();
		
		
		int x=0;
		while(x<10)
		{
			li.add(" Nitin "+x);
			x=x+1;
		}
		System.out.println(li);
		System.out.println(li.get(9));
		li.add("10");
		System.out.println(li);
		li.set(2, "Bhosdi wala");
		System.out.println(li);
		li.add(3, "MC");
		System.out.println(li);
		li.remove(0);
		System.out.println(li);
		li.remove("Bhosdi wala");
		System.out.println(li);
		System.out.println("#$&^*^&*)(*&)__*)_((*)(*_(");
		System.out.println(li1);
		li1.addAll(li);
		System.out.println(li1);
		li1.addAll(2, li);
		System.out.println(li1);
		System.out.println(li.indexOf("MC"));
		Collections.sort(li1);
		System.out.println(li1);
		
		
		Set<String> S = new HashSet<String>();
		S.addAll(li1);
		System.out.println(S);
		S.add("ytrcuituity i");
		System.out.println(S);
		S.add("ytrcuituity j");
		System.out.println(S);
		
		List<String> li2= new LinkedList<String>();
		li2.addAll(S);
		System.out.println(li2);
		
		
	}
}

