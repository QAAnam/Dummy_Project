package utility;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import base_Library.Base_Library;

public class SeleniumUtil 
{
	private static final Logger logger = LogManager.getLogger(SeleniumUtil.class);

	public static void click_on_element(WebElement ele, WebDriver driver)
	{
		Print_Utility.printspecific(logger, new Object() {}, Thread.currentThread().getStackTrace()[1]);
		try
		{
			JavaScriptUtil.scroll_to_WebElement(ele, driver);
		} catch (Exception e)
		{
			e.printStackTrace();
			Print_Utility.get_print("Not able to scroll");
		}
		try
		{
			ele.click();
			Print_Utility.get_print("ele is clciked");
		} 
		catch (ElementClickInterceptedException e) 
		{
			e.printStackTrace();
			try 
			{
				JavaScriptUtil.getClickWithJavaScript(ele, driver);
				Print_Utility.get_print("ele is not clciked with selenium ||| handled with java script");
			} 
			catch (Exception e2)
			{
				e.printStackTrace();
			}
		} 
		catch (StaleElementReferenceException e) 
		{
			e.printStackTrace();
			try
			{
				JavaScriptUtil.getClickWithJavaScript(ele, driver);
				Print_Utility.get_print("ele is not clciked with selenium ||| handled with java script");
			} 
			catch (Exception e2)
			{
				e.printStackTrace();
			}
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}

	}

	public static void sendKey_to_element(WebElement ele, String s, WebDriver driver)
	{
		Print_Utility.printspecific(logger, new Object() {}, Thread.currentThread().getStackTrace()[1]);
		try
		{
			JavaScriptUtil.scroll_to_WebElement(ele, driver);
		} catch (Exception e)
		{
			e.printStackTrace();
			Print_Utility.get_print("Not able to scroll");
		}
		try
		{
			ele.sendKeys(s);
			Print_Utility.get_print("keys are sent");
		} 
		catch (Exception e)
		{
			Print_Utility.get_print("not sent handling with java script");
			e.printStackTrace();
			try 
			{
				JavaScriptUtil.send_key_with_javaScript(ele, s, driver);
			} catch (Exception e2)
			{
				Print_Utility.get_print("not handlsd with java script");
				e.printStackTrace();
			}

		}

	}

}
