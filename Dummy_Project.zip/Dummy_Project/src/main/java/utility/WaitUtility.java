package utility;

import java.time.Duration;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WaitUtility 
{
	private static WebDriverWait wait;
	private static final Logger logger= LogManager.getLogger(WaitUtility.class);
	public static void waitforsec(int x)
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);
		try {
			Thread.sleep(x*1000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void waitforsec()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);
		try {
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void wait_until_displayed(By x)
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(x));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void wait_until_Activated(WebElement ele, WebDriver driver)
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);
		try
		{
			wait=new WebDriverWait(driver, Duration.ofSeconds(10));
			wait.until(ExpectedConditions.elementToBeClickable(ele));
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	

}
