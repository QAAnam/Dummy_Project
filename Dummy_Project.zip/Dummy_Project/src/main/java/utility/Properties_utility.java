package utility;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import base_Library.Base_Library;

import java.util.Properties;
import java.util.Set;

import enums.PropertiesType;
import projectConstants.ProjectConstants;

public final class Properties_utility 
{
	private static final Logger logger= LogManager.getLogger(Properties_utility.class);
	static Properties prop;
	private Properties_utility() {}
	private static Map<String, String> map = new HashMap<String, String>();
	static
	{
		
		try 
		{
			prop = new Properties();
			File f= new File(ProjectConstants.getINSTANCE().getConfig_file_path());
			FileInputStream fis =new FileInputStream(f);
			prop.load(fis);
			Set<Entry<Object, Object>> all_set = prop.entrySet();
			all_set.forEach(e->map.put(String.valueOf(e.getKey()), String.valueOf(e.getValue())));
		} 
		catch (Exception e)
		{
			e.printStackTrace();
			System.exit(0);
		}
	}
	public static String get_value_from_Config_file(PropertiesType key)
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);
		return map.get(key.name().toLowerCase());
		
	}
	

}
