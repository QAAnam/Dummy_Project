package utility;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import base_Library.Base_Library;

public class Print_Utility 
{
	private static final Logger logger= LogManager.getLogger(Print_Utility.class);
	public static void get_print(String s)
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);	
		System.out.print("*************************************>>>> ");
		System.out.print(s);
		System.out.println(" <<<<*****************************************");
	}
	public static void get_print(int s)
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);	
		System.out.print("*************************************>>>> ");
		System.out.print(s);
		System.out.println(" <<<<*****************************************");
	}
	public static void get_print(Object s)
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);	
		System.out.print("*************************************>>>> ");
		System.out.print(s);
		System.out.println(" <<<<*****************************************");
	}
	public static void get_print(List<Object> s)
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);	
		System.out.print("*************************************>>>> ");
		System.out.print(s);
		System.out.println(" <<<<*****************************************");
	}
	public static void printspecific(Logger logger,Object o,StackTraceElement  t )
	{
		
		String s = o.getClass().getEnclosingMethod().getName() + ">>>>> Line number : "+ t.getLineNumber()+" is executing ";
//		logger.trace(s);
//        logger.debug(s);
        logger.info(s);
//        logger.warn(s);
//        logger.error(s);
//        logger.fatal(s);
        
		
	}
	

}
