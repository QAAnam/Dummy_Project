package utility;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class JavaScriptUtil
{
	private static final Logger logger= LogManager.getLogger(JavaScriptUtil.class);
	
	public static void getClickWithJavaScript(WebElement Ele,WebDriver driver)
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);
		try 
		{
			JavascriptExecutor js =(JavascriptExecutor)driver;
			js.executeScript("arguments[0].click();", Ele);
			Print_Utility.get_print("clicked by javascript "+Ele);
		}
		catch (Exception e) 
		{
			Print_Utility.get_print("Error in click with java script "+Ele);
			e.printStackTrace();
			
		}
	}
	public static void send_key_with_javaScript(WebElement ele,String s,WebDriver driver)
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);
		try 
		{
			JavascriptExecutor js =(JavascriptExecutor)driver;
			js.executeScript("arguments[0].setAttribute('value', '" + s +"')", ele);
			Print_Utility.get_print("sent by javascript "+ele);
		}
		catch (Exception e) 
		{
			Print_Utility.get_print("Error in sent with java script "+ele);
			e.printStackTrace();
			
		}
	}
	public static void scroll_to_WebElement(WebElement Ele,WebDriver driver)
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);
		try 
		{
			JavascriptExecutor js =(JavascriptExecutor)driver;
			js.executeScript("arguments[0].scrollIntoView();", Ele);
			Print_Utility.get_print("clicked by javascript "+Ele);



		}
		catch (Exception e) 
		{
			Print_Utility.get_print("Error in click with java script "+Ele);
			e.printStackTrace();
			
		}
	}

}
