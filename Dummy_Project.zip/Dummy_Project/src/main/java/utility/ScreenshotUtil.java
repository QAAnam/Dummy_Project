package utility;

import java.io.File;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.google.common.io.Files;

public final class ScreenshotUtil {

	private ScreenshotUtil()
	{
		
	}
	public static File get_ScreenShot_of_Element(WebElement ele)
	{
		TakesScreenshot ts = (TakesScreenshot)ele;
		File sc = ts.getScreenshotAs(OutputType.FILE);
		try {
			Files.copy(sc, FileUtility.get_file_with_path("Scr.jpg", ""));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return FileUtility.get_file_with_path("Scr.jpg", "");
	}

}
