package utility;

import java.util.Set;

import org.openqa.selenium.WebDriver;

public class Window_manage_util 
{
	public static void close_all_other_window(String Current_win_handle, WebDriver driver )
	{
		Set<String> all_hand = driver.getWindowHandles();
		for(String s : all_hand)
		{
			if(!s.equalsIgnoreCase(Current_win_handle))
			{
				driver.switchTo().window(s);
				driver.close();
			}
		}
		driver.switchTo().window(Current_win_handle);
	}
	

}
