package utility;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import pages.Practice_Form_Page;

public class Robo_utility
{
	 private static final Logger logger = LogManager.getLogger(Practice_Form_Page.class);
	private static Robot robo;
	public static void press_Release_key(int keyevent_key)
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);
		
		try
		{
			robo = new Robot();
			robo.keyPress(keyevent_key);
			robo.keyRelease(keyevent_key);
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public static void press_Release_key(int keyevent_key,int keyevent_key1)
	{
		try
		{
			robo = new Robot();
			robo.keyPress(keyevent_key);
			robo.keyPress(keyevent_key1);
			robo.keyRelease(keyevent_key1);
			robo.keyRelease(keyevent_key);
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public static void Copy_paste(String s)
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);
		try
		{
			StringSelection ss= new StringSelection(s);
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
			press_Release_key(KeyEvent.VK_CONTROL, KeyEvent.VK_V);
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	public static void main(String[] args) {
		Copy_paste("s");
	}
	

}
