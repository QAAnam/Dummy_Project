package utility;

import java.io.File;

import projectConstants.ProjectConstants;

public class FileUtility 
{
	public static File get_file_with_path(String s)
	{
		File f = null;
		try
		{
			f=new File(s);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			System.exit(0);
		}
		
		return f;
	}
	public static File get_file_with_path(String s, String folder)
	{
		File f = null;
		try
		{
			f=new File(ProjectConstants.getINSTANCE().get_output_Screenshot_path(s));
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			System.exit(0);
		}
		
		return f;
	}

}
