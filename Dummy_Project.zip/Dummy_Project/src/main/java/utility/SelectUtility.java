package utility;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class SelectUtility {
	
	private static final Logger logger= LogManager.getLogger(SelectUtility.class);
	
	public static void select_By_Text(WebElement ele, String s)
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);
		Select sl = new Select(ele);
		sl.selectByVisibleText(s);
	}
	public static WebElement select_from_list_By_Text(List<WebElement> ele, String s)
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);
		WebElement ele1 = null;
		if(ele.size()<1) 
		{
			Print_Utility.get_print("list is empty");
		}
		for(WebElement e: ele)
		{
			if(e.getText().equalsIgnoreCase(s))
			{
				ele1=e;
			}
		}
		return ele1;
	}
	public static void click_from_list(List<WebElement> ele, String s, WebDriver driver)
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);
		WebElement ele1 = select_from_list_By_Text(ele,s);
		SeleniumUtil.click_on_element(ele1, driver);
	}

}
