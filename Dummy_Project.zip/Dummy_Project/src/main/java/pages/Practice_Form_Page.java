package pages;

import java.io.File;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import base_Library.Base_Library;
import enums.PropertiesType;
import projectConstants.ProjectConstants;
import reportExtent.Extent_Logger;
import utility.Print_Utility;
import utility.Properties_utility;
import utility.ScreenshotUtil;
import utility.SelectUtility;
import utility.SeleniumUtil;
import utility.WaitUtility;

public class Practice_Form_Page extends Base_Library
{
	 private static final Logger logger = LogManager.getLogger(Practice_Form_Page.class);
	 
	public Practice_Form_Page() 
	{
		Print_Utility.get_print("Practice_Form_Page constructor is executed ");
		this.driver= Base_Library.get_initilized_driver();
		PageFactory.initElements(driver, this);
	}
	private static WebDriver driver;
	
	@FindBy(id = "firstName")
	private WebElement firstname;
	@FindBy(id = "lastName")
	private WebElement lastname;	
	@FindBy(id = "userEmail")
	private WebElement userEmail;	
	@FindBy(id="gender-radio-1")
	private WebElement gender1;
	@FindBy(id="gender-radio-2")
	private WebElement gender2;
	@FindBy(id="gender-radio-3")
	private WebElement gender3;
	@FindBy(xpath="//label[@for='gender-radio-1']")
	private WebElement click_gender1;
	@FindBy(xpath="//label[@for='gender-radio-2']")
	private WebElement click_gender2;
	@FindBy(xpath="//label[@for='gender-radio-3']")
	private WebElement click_gender3;
	@FindBy(id="userNumber")
	private WebElement userNumber;
	@FindBy(id="dateOfBirthInput")
	private WebElement dateOfBirthInput;
	@FindBy (className = "react-datepicker__month-select")
	private WebElement datepicker__month;
	@FindBy (className = "react-datepicker__year-select")
	private WebElement datepicker__year;
	@FindBy(xpath="(//div[contains(@class, 'react-datepicker__day--025')])[2]")
	private WebElement datepicker__day;
	@FindBy(xpath = "//input[@id='subjectsInput']")
	private WebElement subjects;
	@FindBy(id="react-select-2-option-5")
	private List<WebElement> Hissubjects;
	@FindBy(id="hobbies-checkbox-1")
	private WebElement hobbies_Sports;
	@FindBy(id="hobbies-checkbox-2")
	private WebElement hobbies_Reading;
	@FindBy(id="hobbies-checkbox-3")
	private WebElement hobbies_Music;
	@FindBy(xpath="//label[@for='hobbies-checkbox-1']")
	private WebElement Click_hobbies_Sports;
	@FindBy(xpath="//label[@for='hobbies-checkbox-2']")
	private WebElement Click_hobbies_Reading;
	@FindBy(xpath="//label[@for='hobbies-checkbox-3']")
	private WebElement Click_hobbies_Music;
	@FindBy(xpath="//label[@for='uploadPicture']")
	private WebElement up_pic;
	@FindBy(xpath="//input[@id='uploadPicture']")
	private WebElement send_up_pic;
	@FindBy(id="currentAddress")
	private WebElement currentaddress;
	@FindBy(xpath="//*[text()='Select State']")
	private WebElement select_state;
	@FindBy(xpath="//*[@class=' css-11unzgr']//div")
	private List<WebElement> select_state_op;
	@FindBy(xpath="//*[text()='Select City']")
	private WebElement select_city;
	@FindBy(id="userForm")
	private WebElement submit_form;
	public void get_url_launch()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);
		driver.get("https://demoqa.com/automation-practice-form");
	} 
	public void set_first_name()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);		
		firstname.sendKeys("Anam");
		File f = ScreenshotUtil.get_ScreenShot_of_Element(firstname);
		Extent_Logger.on_log_response("firstname", f);

	}
	public void set_last_name()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);
		
		userEmail.sendKeys("anam@mailinator.com");
		WaitUtility.waitforsec(1);
	}
	public void set_email()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);
		
		lastname.sendKeys("Kumar");
		WaitUtility.waitforsec(1);
	}
	public void set_gender()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);
		if (Properties_utility.get_value_from_Config_file(PropertiesType.gender).equalsIgnoreCase("male")) 
		{
			if (!gender1.isSelected())
			{
				SeleniumUtil.click_on_element(click_gender1, driver);
			}
		}
		if (Properties_utility.get_value_from_Config_file(PropertiesType.gender).equalsIgnoreCase("female")) 
		{
			if (!gender1.isSelected())
			{
				SeleniumUtil.click_on_element(click_gender1, driver);
			}
		}
		if (Properties_utility.get_value_from_Config_file(PropertiesType.gender).equalsIgnoreCase("other")) 
		{
			if (!gender1.isSelected())
			{
				SeleniumUtil.click_on_element(click_gender1, driver);
			}
		}
		
	}
	public void set_mobile_Number()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);
		SeleniumUtil.sendKey_to_element(userNumber, "1234567890", driver);
		WaitUtility.waitforsec(1);
	}
	public void clickonCelender()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);
		SeleniumUtil.click_on_element(dateOfBirthInput, driver);
		WaitUtility.waitforsec(1);
	}
	public void setmonth()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);
		SelectUtility.select_By_Text(datepicker__month, "December");
		WaitUtility.waitforsec(1);
	}
	public void setyear()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);
		SelectUtility.select_By_Text(datepicker__year, "1990");
		WaitUtility.waitforsec(1);
	}
	public void setday()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);
		SeleniumUtil.click_on_element(datepicker__day, driver);;
		WaitUtility.waitforsec(1);
	}
	public void set_subject()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);
		//SeleniumUtil.click_on_element(subjects, driver);
		String H="H";
		SeleniumUtil.sendKey_to_element(subjects, H, driver);
		WaitUtility.waitforsec(1);
	}
	public void set_subject_from_suggession()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);		
		SelectUtility.click_from_list(Hissubjects, "History", driver);
		WaitUtility.waitforsec(1);
	}
	public void setHobbies()
	{
		
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);	
		
		if(Properties_utility.get_value_from_Config_file(PropertiesType.music).equalsIgnoreCase("yes"))
		{
			if (! hobbies_Music.isSelected())
			{
				SeleniumUtil.click_on_element(Click_hobbies_Music, driver);
			}
		}
		if(Properties_utility.get_value_from_Config_file(PropertiesType.reading).equalsIgnoreCase("yes"))
		{
			if (! hobbies_Reading.isSelected())
			{
				SeleniumUtil.click_on_element(Click_hobbies_Reading, driver);
			}
		}
		if(Properties_utility.get_value_from_Config_file(PropertiesType.sport).equalsIgnoreCase("yes"))
		{
			if (! hobbies_Sports.isSelected())
			{
				SeleniumUtil.click_on_element(Click_hobbies_Sports,driver);
			}
		}
	}
	public void send_uploadPicture()
	{
		String S = ProjectConstants.getINSTANCE().get_input_image_folder_path("images (8).jpg");
		SeleniumUtil.sendKey_to_element(send_up_pic, S, driver);
		
	}
	public void setaddress()
	{
		SeleniumUtil.sendKey_to_element(currentaddress, "Adress : wahi hai", driver);
	}
	public void Set_state()
	{
		SeleniumUtil.click_on_element(select_state, driver);
		WaitUtility.waitforsec();
	}
	public void set_state_option() 
	{
		SelectUtility.click_from_list(select_state_op, "Rajasthan", driver);
	}
	public void set_City()
	{
		WaitUtility.wait_until_Activated(select_city,driver);
		SeleniumUtil.click_on_element(select_city, driver);
	}
	public void set_City_op()
	{
		WaitUtility.wait_until_Activated(select_state_op.get(0),driver);
		SelectUtility.click_from_list(select_state_op, "Jaiselmer", driver);
	}
	public void click_submit_form()
	{
		submit_form.submit();
	}
	


}
