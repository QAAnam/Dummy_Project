package reportExtent;

import com.aventstack.extentreports.ExtentTest;

public final class Extent_manager {
	
	private Extent_manager() {}

	private static ThreadLocal<ExtentTest> thread_ext_test=new ThreadLocal<>();
	
	public static void set_thread_ext_test(ExtentTest ex_test)
	{
		thread_ext_test.set(ex_test);		
	}
	public static ExtentTest get_thread_ext_test()
	{
		return thread_ext_test.get();	
	}

}
