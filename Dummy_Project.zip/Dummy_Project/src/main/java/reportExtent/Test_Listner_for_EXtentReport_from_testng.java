package reportExtent;

import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestNGListener;
import org.testng.ITestResult;

public class Test_Listner_for_EXtentReport_from_testng implements ISuiteListener, ITestListener
{

	@Override
	public void onStart(ISuite suite)
	{
		Extent_Reporter.inti_report();
	}

	@Override
	public void onFinish(ISuite suite) {
		Extent_Reporter.end_report();
	}

	@Override
	public void onTestStart(ITestResult result) {
		Extent_Reporter.add_test_report(result.getName().toString());
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		Extent_Logger.on_pass(result.getName().toString());
	}

	@Override
	public void onTestFailure(ITestResult result) {
		Extent_Logger.on_fail(result.getName().toString());
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		Extent_Logger.on_info(result.getName().toString()); 
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		Extent_Logger.on_info(result.getName().toString()); 
	}

	@Override
	public void onTestFailedWithTimeout(ITestResult result) {
		Extent_Logger.on_info(result.getName().toString()); 
	}

	

}
