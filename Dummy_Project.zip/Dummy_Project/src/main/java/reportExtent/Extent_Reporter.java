package reportExtent;

import java.io.File;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import projectConstants.ProjectConstants;
import utility.FileUtility;

public class Extent_Reporter
{
	private Extent_Reporter() {
		// TODO Auto-generated constructor stub
	}
	private static ExtentReports extent_report;
	private static ExtentTest extenttest ;
	public static void inti_report()
	{
		extent_report=new ExtentReports();
		File f = FileUtility.get_file_with_path(ProjectConstants.getINSTANCE().get_output_extent_repo_path("Spark.html"));
		ExtentSparkReporter spark = new ExtentSparkReporter(f);
		extent_report.attachReporter(spark);
	}
	public static void end_report()
	{
		extent_report.flush();
	}
	public static void add_test_report(String m)
	{
		extenttest=extent_report.createTest(m);
		Extent_manager.set_thread_ext_test(extenttest);
	}

}
