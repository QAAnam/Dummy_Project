package base_Library;


import java.io.File;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import enums.PropertiesType;
import pages.Practice_Form_Page;
import projectConstants.ProjectConstants;
import utility.FileUtility;
import utility.Print_Utility;
import utility.Properties_utility;
import utility.WaitUtility;
import utility.Window_manage_util;

public class Base_Library 
{
	private static final Logger logger= LogManager.getLogger(Base_Library.class);
	public static WebDriver driver;
	
	@BeforeClass
	public WebDriver launch_driver()
	{		
		
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);		
		ChromeOptions ops = new ChromeOptions();
		if(Properties_utility.get_value_from_Config_file(PropertiesType.chromeops).equalsIgnoreCase("yes"))
		{
			
			File file = FileUtility.get_file_with_path(ProjectConstants.getINSTANCE().get_input_setup_folder_path("adblock.crx"));
			ops.addExtensions(file);
		}
		
		driver= new ChromeDriver(ops);
		
		driver.manage().window().maximize();
		driver.navigate().refresh();
		if (Properties_utility.get_value_from_Config_file(PropertiesType.chromeops).equalsIgnoreCase("yes")) 
		{
			WaitUtility.waitforsec(3);
			Window_manage_util.close_all_other_window(driver.getWindowHandle(), driver);
		}
		return driver;
	}
	public static WebDriver get_initilized_driver()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);
		return driver;
	}
	@AfterClass
	public void close_browser() throws InterruptedException
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);
		Thread.sleep(10000);
		driver.quit();
	}
	

}
