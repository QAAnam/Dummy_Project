package tests;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.Test;

import base_Library.Base_Library;
import pages.Practice_Form_Page;
import utility.Print_Utility;

public class Practice_Form_Test extends Base_Library
{
	private static final Logger logger= LogManager.getLogger(Practice_Form_Test.class);
	private Practice_Form_Page obj;
	@Test(priority = 0)
	public void test_Driver_Initialization()
	{
		obj=new Practice_Form_Page();
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);	
		
	}
	@Test(priority = 1)
	public void test_get_url_launch()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);	
		obj.get_url_launch();
	}
	@Test(priority = 2)
	public void test_set_email()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);	
		obj.set_email();
	}
	@Test(priority = 3)
	public void test_set_first_name()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);	
		obj.set_first_name();
	}
	@Test(priority = 4)
	public void test_set_last_name()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);	
		obj.set_last_name();
	}
	@Test(priority = 5)
	public void test_set_gender()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);	
		obj.set_gender();
	}
	@Test(priority = 6)
	public void test_set_mobile_Number()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);	
		obj.set_mobile_Number();
	}
	@Test(priority = 7)
	public void test_clickonCelender()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);	
		obj.clickonCelender();
	}
	@Test(priority = 8)
	public void test_setyear()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);	
		obj.setyear();
	}
	@Test(priority = 9)
	public void test_setmonth()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);	
		obj.setmonth();
	}
	@Test(priority = 10)
	public void test_setday()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);	
		obj.setday();
	}
	@Test(priority = 11)
	public void test_set_subject()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);	
		obj.set_subject();
	}
	@Test(priority = 12)
	public void test_set_subject_from_suggession()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);	
		obj.set_subject_from_suggession();
		obj.setHobbies();
	}
	@Test(priority = 13)
	public void test_setHobbies()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);	
		obj.setHobbies();
	}
	@Test(priority = 14)
	public void test_uploadPicture()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);	
		obj.send_uploadPicture();
	}
	@Test(priority = 15)
	public void test_setaddress()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);	
		obj.setaddress();
	}
	@Test(priority = 16)
	public void test_Set_state()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);	
		obj.Set_state();
	}
	@Test(priority = 17)
	public void test_set_state_option()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);	
		obj.set_state_option();
	}
	@Test(priority = 18)
	public void test_set_City()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);	
		obj.set_City();
	}
	@Test(priority = 19)
	public void test_set_City_op()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);	
		obj.set_City_op();
	}
	@Test(priority = 20)
	public void test_click_submit_form()
	{
		Print_Utility.printspecific(logger,new Object() {}, Thread.currentThread().getStackTrace()[1]);	
		obj.click_submit_form();
	}

}
