1.**start-maximized:** Opens Chrome in maximize mode
2.__incognito__: Opens Chrome in incognito mode
3.**headless**: Opens Chrome in headless mode
1.**disable-extensions**: Disables existing extensions on Chrome browser
1.**disable-popup-blocking**: Disables pop-ups displayed on Chrome browser
1.**make-default-browser:** Makes Chrome default browser
1.**version**: Prints chrome browser version
1.**disable-infobars**: Prevents Chrome from displaying the notification ‘Chrome is being controlled by automated software